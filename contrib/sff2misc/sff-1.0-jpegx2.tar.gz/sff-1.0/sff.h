/* $Id: sff.h,v 1.2 1998/10/08 09:06:19 fritz Exp $
 *
 * sff2pbm - a converter from StructuredFaxFormat to PortableBitMap
 *
 * (c) 1998 by Fritz Elfert
 *
 * $Log: sff.h,v $
 * Revision 1.2  1998/10/08 09:06:19  fritz
 * Added jpeg and PostScript output.
 *
 * Revision 1.1  1998/10/07 04:27:49  fritz
 * First check in.
 *
 */
#ifndef _SFF_H_
#define _SFF_H_

#include <linux/types.h>

typedef struct sff_dochdr {
	__u32 magic         __attribute__ ((packed));
	__u8  version       __attribute__ ((packed));
	__u8  reserved      __attribute__ ((packed));
	__u16 userinfo      __attribute__ ((packed));
	__u16 pagecount     __attribute__ ((packed));
	__u16 offsetfirstph __attribute__ ((packed));
	__u32 offsetlastph  __attribute__ ((packed));
	__u32 offsetdocend  __attribute__ ((packed));
} sff_dochdr;

typedef struct sff_paghdr {
//	__u8  id           __attribute__ ((packed));
//	__u8  len          __attribute__ ((packed));
	__u8  vres         __attribute__ ((packed));
	__u8  hres         __attribute__ ((packed));
	__u8  coding       __attribute__ ((packed));
	__u8  reserverd    __attribute__ ((packed));
	__u16 linelen      __attribute__ ((packed));
	__u16 pagelen      __attribute__ ((packed));
	__u32 offsetprev   __attribute__ ((packed));
	__u32 offsetnext   __attribute__ ((packed));
} sff_paghdr;

#define SFF_MAGIC "Sfff"

typedef struct sff_file {
	int currentp;
	int inpage;
	int skip;
	int eol;
	int eoladd;
	unsigned short rep;
	int currentline;
	sff_dochdr dochdr;
	sff_paghdr paghdr;
	FILE *f;
} sff_file;

extern sff_file *open_sff(char *name, char *mode);
extern int getG3byte(sff_file *ff, char *byte);
extern int decodeSFF(sff_file *ff, char *name, int format);
#endif
