/* $Id: sfffunc.c,v 1.4 1998/10/11 20:00:15 fritz Exp $
 *
 * sff2pbm - a converter from StructuredFaxFormat to PortableBitMap
 *
 * (c) 1998 by Fritz Elfert
 *
 * $Log: sfffunc.c,v $
 * Revision 1.4  1998/10/11 20:00:15  fritz
 * Bugfix: Multipage docs were nont properly handled.
 *
 * Revision 1.3  1998/10/09 15:42:44  fritz
 * Some redhat related changes.
 *
 * Revision 1.2  1998/10/08 09:06:21  fritz
 * Added jpeg and PostScript output.
 *
 * Revision 1.1  1998/10/07 04:27:49  fritz
 * First check in.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>

#include "sff.h"
#include "g3decode.h"

#include "jpeglib.h"

static int bitsavail;
static unsigned short xprobe;
static unsigned char *iptr;
static unsigned char outbuf[2048];
static unsigned char inbuf[1024];

sff_file *open_sff(char *name, char *mode) {
	sff_file *ff;
	int r;
	unsigned char c;

	ff = (sff_file *)malloc(sizeof(sff_file));
	if (ff != NULL) {
		if (!strcmp(mode, "r")) {
			ff->f = fopen(name, mode);
			if (ff->f == NULL) {
				free(ff);
				return NULL;
			} else {
				r = fread(&ff->dochdr, 1, sizeof(sff_dochdr), ff->f);
				if ((r != sizeof(sff_dochdr)) ||
					(strncmp((char *)&ff->dochdr.magic, SFF_MAGIC, 4)) ||
					(ff->dochdr.version != 1)) {
					fclose(ff->f);
					free(ff);
					return NULL;
				}
				if (ff->dochdr.offsetfirstph > sizeof(sff_dochdr))
					fread(inbuf, ff->dochdr.offsetfirstph - sizeof(sff_dochdr),
						1, ff->f);
				/* Read first page header */
				if ((r = fread(&c, 1, 1, ff->f)) != 1) {
					free(ff);
					return NULL;
				}
				if (c != 254) {
					free(ff);
					return NULL;
				}
				if ((r = fread(&c, 1, 1, ff->f)) != 1) {
					free(ff);
					return NULL;
				}
				if (c == 0) {
					free(ff);
					return NULL;
				}
				if ((r = fread(&ff->paghdr, 1, sizeof(sff_paghdr),
					ff->f)) != sizeof(sff_paghdr)) {
					free(ff);
					return NULL;
				}
			} 
		}
		if (!strcmp(mode, "w")) {
			ff->f = fopen(name, mode);
			if (ff->f == NULL) {
				free(ff);
				return NULL;
			} else {
				memcpy(&ff->dochdr.magic, SFF_MAGIC, 4);
				ff->dochdr.version = 1;
				ff->dochdr.reserved = 0;
				ff->dochdr.userinfo = 0;
				ff->dochdr.pagecount = 0;
				ff->dochdr.offsetfirstph = 0x14;
				ff->dochdr.offsetlastph = 0;
				ff->dochdr.offsetdocend = 0;
				r = fwrite(&ff->dochdr, 1, sizeof(sff_dochdr), ff->f);
				if (r != sizeof(sff_dochdr)) {
					fclose(ff->f);
					free(ff);
					return NULL;
				}
			}
		}
	}
	ff->currentp = 0;
	ff->inpage = 0;
	ff->rep = 0;
	ff->skip = 0;
	ff->eol = 0;
	return ff;
}

int getG3byte(sff_file *ff, char *byte) {
	int r;
    unsigned char c;
	char dummy[256];

	do {
		if ((r = fread(&c, 1, 1, ff->f)) != 1)
			return r;
		if (ff->rep > 0) {
			*byte = c;
			if (--ff->rep == 0)
				return 66; /* EOL */
			return 65;
		}
		if (c == 0) {
			fread(&ff->rep, 1, 2, ff->f);
			continue;
		}
		if ((c > 1) && (c < 217)) {
			ff->rep = (unsigned short)c;
			continue;
		}
		if ((c > 216) && (c < 254))
			return c - 216;
		switch (c) {
			case 254:
				/* New page header or EOF */
				if ((r = fread(&c, 1, 1, ff->f)) != 1)
					return r;
				if (c == 0)
					return 0; /* EOF */
				if ((r = fread(&ff->paghdr, 1, sizeof(sff_paghdr), ff->f)) != sizeof(sff_paghdr))
					return -1;
				return 128;
				break;
			case 255:
				fread(&c, 1, 1, ff->f);
				if (c)
					fread(dummy, 1, c, ff->f);
				break;
		}
	} while (1);
	return 0;
}

int getG3line(sff_file *ff, unsigned char *buf) {
	unsigned char *p = buf;
	int count = 0;
	int r;

	do {
		if (ff->skip) {
			ff->skip--;
			return -1; /* Empty Line */
		}
		r = getG3byte(ff, p++);
		if (r & 128)
			return -2; /* EOP */
		if (r & 64) {
			count++;
		} else {
			if (r == 0)
				return -3; /* EOF */
			/* blank line */
			ff->skip = r;
		}
	} while (r != 66);
	return count;
}

static void drawrunJ(int x, int len, int black) {
	int i;
	unsigned char *p = outbuf;

	p += x;
	for (i=0; i<len; i++)
		*p++ = 0;
}

static void drawrunP(int x, int len, int black) {
	unsigned char *p = outbuf + (x / 8);
	unsigned char mask = 0x80 >> (x % 8);

	while (mask && len) {
		*p |= mask;
		mask >>= 1;
		len--;
	}
	p++;
	while (len >= 8) {
		*p++ = 0xff;
		len -= 8;
	}
	mask = 0x80;
	while (len) {
		*p |= mask;
		mask >>= 1;
		len--;
	}
}

typedef void (*drawrun_t)(int, int, int);
drawrun_t drawrun;

static void getbits(int bits) {
	int i;

	for (i=0; i<bits; i++) {
		if (!bitsavail) {
			iptr++;
			bitsavail = 8;
		}
		xprobe <<= 1;
		xprobe |= (*iptr & 1);
		*iptr >>= 1;
		bitsavail--;
	}
}

static void g3decode(int n) {
	int x = 0;
	int i;
	int j;
	int run;
	unsigned short mask;
	tableentry *te;

	iptr = inbuf;
	bitsavail = 8;
	xprobe = 0;
	getbits(16);
	while (x < 1728) {
		if ((xprobe & 0xffe0) == 0)
			return; /* EOL */
		run = 0;
		for (i=0; i<MWTANZ; i++) {
			mask = mwtable[i].mask;
			te = mwtable[i].tab;
			for (j=0; j<mwtable[i].tlen; j++) {
				if ((xprobe & mask) == te[j].code) {
					run += te[j].count;
					getbits(mwtable[i].bits);
					i = MWTANZ;
					break;
				}
			}
		}
		for (i=0; i<TWTANZ; i++) {
			mask = twtable[i].mask;
			te = twtable[i].tab;
			for (j=0; j<twtable[i].tlen; j++) {
				if ((xprobe & mask) == te[j].code) {
					run += te[j].count;
					getbits(twtable[i].bits);
					i = TWTANZ + 1;
					break;
				}
			}
		}
		if (i < (TWTANZ + 1)) {
			fprintf(stderr, "Invalid white MH runlength, skipping to EOL\n");
			return;
		}
		if ((xprobe & 0xffe0) == 0)
			return; /* EOL */
		x += run;
		run = 0;
		for (i=0; i<MBTANZ; i++) {
			mask = mbtable[i].mask;
			te = mbtable[i].tab;
			for (j=0; j<mbtable[i].tlen; j++) {
				if ((xprobe & mask) == te[j].code) {
					run += te[j].count;
					getbits(mbtable[i].bits);
					i = MBTANZ;
					break;
				}
			}
		}
		for (i=0; i<TBTANZ; i++) {
			mask = tbtable[i].mask;
			te = tbtable[i].tab;
			for (j=0; j<tbtable[i].tlen; j++) {
				if ((xprobe & mask) == te[j].code) {
					run += te[j].count;
					getbits(tbtable[i].bits);
					i = TBTANZ + 1;
					break;
				}
			}
		}
		if (i < (TBTANZ + 1)) {
			fprintf(stderr, "Invalid black MH runlength, skipping to EOL\n");
			return;
		}
		drawrun(x, run, 1);
		x += run;
	}
}

/* MUST only be called, after reading a Page-Header !!! */

static int getSFFheight(sff_file *ff) {
	unsigned long hpos;
	int h = 0;
	int loop = 1;

	hpos = ftell(ff->f);
	do {
		switch (getG3line(ff, inbuf)) {
			case -2:
			case -3:
				loop = 0;
				break;
			default:
				h++;
				break;
		}
	} while (loop);
	fseek(ff->f, hpos, SEEK_SET);
	return h;
}

static void write_ps_doc_header(FILE *f, char *name) {
	fprintf(f, "%%!PS-Adobe-2.0\n");
	fprintf(f, "%%%%Creator: sff2misc 1.0\n");
	fprintf(f, "%%%%Title: %s\n", name);
	fprintf(f, "%%%%DocumentData: Clean7Bit\n");
//	fprintf(f, "%%%%Pages: %d\n", pages);
	fprintf(f, "%%%%PageOrder: Ascend\n");
	fprintf(f, "%%%%BoundingBox: 0 0 595 842\n");
	fprintf(f, "%%%%DocumentPaperSizes: A4\n");
	fprintf(f, "%%%%EndComments\n");
	fprintf(f, "%%%%EndProlog\n");
}

static void write_ps_pag_header(FILE *f, int page, int height) {
	fprintf(f, "%%%%Page: %d %d\n", page, page);
	fprintf(f, "5 dict begin\n");
	fprintf(f, "0.10 832.0 translate\n");
	fprintf(f, "585.0 -822.0 scale\n");
	fprintf(f, "/scanline 216 string def\n");
	fprintf(f, "1728 %d 1\n", height);
	fprintf(f, "[ 1728 0 0 %d 0 0 ]\n", height);
	fprintf(f, "{ currentfile scanline readhexstring pop }\n");
	fprintf(f, "image\n");
}

static void write_ps_doc_trailer(FILE *f) {
	fprintf(f, "%%%%EOF\n");
}

static void write_ps_pag_trailer(FILE *f) {
	fprintf(f, "showpage\nend\n");
}

static void write_ps_scanline(FILE *f) {
	int i;

	for (i=0; i<216; i++)
		fprintf(f, "%02x%s", outbuf[i] ^ 255, ((i+1) & 0x3f)?"\0":"\n");
	fprintf(f, "\n");
}

int decodeSFF(sff_file *ff, char *name, int format) {
	int r;
	int lc = 0;
	int pc = 1;
	int done = 0;
	int height;
	int eop;
	FILE *out;
	char *ext;
	char outname[1024];

	struct jpeg_compress_struct cinfo;
	struct jpeg_error_mgr jerr;
	JSAMPROW row_pointer[1];

	switch (format) {
		case 0:
			ext = ".pbm";
			drawrun = drawrunP;
			break;
		case 1:
			cinfo.err = jpeg_std_error(&jerr);
			jpeg_create_compress(&cinfo);
			ext = ".jpg";
			drawrun = drawrunJ;
			break;
		case 2:
			ext = ".ps";
			sprintf(outname, "%s%s", name, ext);
			if ((out = fopen(outname, "w")) == NULL) {
				perror(outname);
				exit(errno);
			}
			write_ps_doc_header(out, name);
			drawrun = drawrunP;
			break;
	}
	do {
		eop = 0;
		height = getSFFheight(ff);
		sprintf(outname, "%s.%03d%s", name, pc, ext);
		switch (format) {
			case 0:
				if ((out = fopen(outname, "w")) == NULL) {
					perror(outname);
					exit(errno);
				}
				fprintf(out, "P4\n");
				fprintf(out, "1728 %d\n", height);
				break;
			case 1:
				if ((out = fopen(outname, "w")) == NULL) {
					perror(outname);
					exit(errno);
				}
				jpeg_stdio_dest(&cinfo, out);
				cinfo.image_width = 1728;
				cinfo.image_height = height*2;
				cinfo.input_components = 1;
				cinfo.in_color_space = JCS_GRAYSCALE;
				cinfo.density_unit = 1;
				cinfo.X_density = 203;
				cinfo.Y_density = ff->paghdr.vres ? 98 : 196;
				jpeg_set_defaults(&cinfo);
				jpeg_set_quality(&cinfo, 40, FALSE);
				jpeg_start_compress(&cinfo, TRUE);
				break;
			case 2:
				write_ps_pag_header(out, pc, height);
				break;
		}
		do {
			switch (format) {
				case 0:
				case 2:
					memset(outbuf, 0, sizeof(outbuf));
					break;
				case 1:
					memset(outbuf, 0xff, sizeof(outbuf));
					break;
			}
			memset(inbuf, 0, sizeof(inbuf));
			r = getG3line(ff, inbuf);
			switch (r) {
				case -1:
					switch (format) {
						case 0:
							/* PBM */
							fwrite(outbuf, 216, 1, out);
				                        if (ff->paghdr.vres == 0)
							   fwrite(outbuf, 216, 1, out);
							break;
						case 1:
							/* JPEG */
							row_pointer[0] = outbuf;
							jpeg_write_scanlines(&cinfo, row_pointer, 1);
							jpeg_write_scanlines(&cinfo, row_pointer, 1);
							break;
						case 2:
							/* PostScript */
							write_ps_scanline(out);
							break;
					}
					lc++;
					break;
				case -2:
					/* EOP */
					eop = 1;
					break;
				case -3:
					/* EOF */
					done = 1;
					break;
				default:
					/* r = bytecount of line */
					while (r & 3)
						r++;
					g3decode(r);
					switch (format) {
						case 0:
							fwrite(outbuf, 216, 1, out);
				                        if (ff->paghdr.vres == 0)
							   fwrite(outbuf, 216, 1, out);
							break;
						case 1:
							row_pointer[0] = outbuf;
							jpeg_write_scanlines(&cinfo, row_pointer, 1);
							jpeg_write_scanlines(&cinfo, row_pointer, 1);
							break;
						case 2:
							/* PostScript */
							write_ps_scanline(out);
							break;
					}
					lc++;
					break;
			}
		} while ((!done) && (!eop));
		switch (format) {
			case 0:
				fclose(out);
				break;
			case 1:
				jpeg_finish_compress(&cinfo);
				fclose(out);
				break;
			case 2:
				write_ps_pag_trailer(out);
				break;
		}
		pc++;
	} while (!done);
	if (format == 2) {
		write_ps_doc_trailer(out);
		fclose(out);
	}
	return 0;
}
