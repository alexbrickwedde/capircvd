/* $Id: g3decode.h,v 1.2 1998/10/07 04:32:49 fritz Exp $
 *
 * sff2pbm - a converter from StructuredFaxFormat to PortableBitMap
 *
 * (c) 1998 by Fritz Elfert
 *
 * $Log: g3decode.h,v $
 * Revision 1.2  1998/10/07 04:32:49  fritz
 * added Id and log.
 *
 *
 */

#ifndef _G3_H_
#define _G3_H_

typedef struct tableentry {
    unsigned short code;
    int count;
} tableentry;

typedef struct ltable {
	unsigned short mask;
	int bits;
	int tlen;
	tableentry *tab;
} ltable;

/* white terminating codes */

static tableentry wt1[] = {  /* 4 bits, left aligned */
	{ 0x7000, 2 },
   	{ 0x8000, 3 },
   	{ 0xb000, 4 },
   	{ 0xc000, 5 },
   	{ 0xe000, 6 },
	{ 0xf000, 7 }
}; 

static struct tableentry wt2[] = { /* 5 bits, left aligned */
    { 0x9800, 8 },
    { 0xa000, 9 },
    { 0x3800, 10 },
    { 0x4000, 11 },
};

static struct tableentry wt3[] = { /* 6 bits, left aligned */
    { 0x1c00, 1 },
    { 0x2000, 12 },
    { 0x0c00, 13 },
    { 0xd000, 14 },
    { 0xd400, 15 },
    { 0xa800, 16 },
    { 0xac00, 17 },
};

static struct tableentry wt4[] = { /* 7 bits, left aligned */
    { 0x4e00, 18 },
    { 0x1800, 19 },
    { 0x1000, 20 },
    { 0x2e00, 21 },
    { 0x0600, 22 },
    { 0x0800, 23 },
    { 0x5000, 24 },
    { 0x5600, 25 },
    { 0x2600, 26 },
    { 0x4800, 27 },
    { 0x3000, 28 },
};

static struct tableentry wt5[] = { /* 8 bits, left aligned */
    { 0x3500, 0 },
    { 0x0200, 29 },
    { 0x0300, 30 },
    { 0x1a00, 31 },
    { 0x1b00, 32 },
    { 0x1200, 33 },
    { 0x1300, 34 },
    { 0x1400, 35 },
    { 0x1500, 36 },
    { 0x1600, 37 },
    { 0x1700, 38 },
    { 0x2800, 39 },
    { 0x2900, 40 },
    { 0x2a00, 41 },
    { 0x2b00, 42 },
    { 0x2c00, 43 },
    { 0x2d00, 44 },
    { 0x0400, 45 },
    { 0x0500, 46 },
    { 0x0a00, 47 },
    { 0x0b00, 48 },
    { 0x5200, 49 },
    { 0x5300, 50 },
    { 0x5400, 51 },
    { 0x5500, 52 },
    { 0x2400, 53 },
    { 0x2500, 54 },
    { 0x5800, 55 },
    { 0x5900, 56 },
    { 0x5a00, 57 },
    { 0x5b00, 58 },
    { 0x4a00, 59 },
    { 0x4b00, 60 },
    { 0x3200, 61 },
    { 0x3300, 62 },
    { 0x3400, 63 },
};

static ltable twtable[] = {
	{ 0xf000, 4,  6, wt1 },
	{ 0xf800, 5,  4, wt2 },
	{ 0xfc00, 6,  7, wt3 },
	{ 0xfe00, 7, 11, wt4 },
	{ 0xff00, 8, 36, wt5 },
};
#define TWTANZ 5

/* white makeup tables */

static struct tableentry wm1[] = { /* 5 bits, left aligned */
    { 0xd800, 64 },
    { 0x9000, 128 },
};

static struct tableentry wm2[] = { /* 6 bits, left aligned */
    { 0x5c00, 192 },
    { 0x6000, 1664 },
};

static struct tableentry wm3[] = { /* 7 bits, left aligned */
    { 0x6e00, 256 },
};

static struct tableentry wm4[] = { /* 8 bits, left aligned */
    { 0x3600, 320 },
    { 0x3700, 384 },
    { 0x6400, 448 },
    { 0x6500, 512 },
    { 0x6800, 576 },
    { 0x6700, 640 },
};

static struct tableentry wm5[] = { /* 9 bits, left aligned */
    { 0x6600, 704 },
    { 0x6680, 768 },
    { 0x6900, 832 },
    { 0x6980, 896 },
    { 0x6a00, 960 },
    { 0x6a80, 1024 },
    { 0x6b00, 1088 },
    { 0x6b80, 1152 },
    { 0x6c00, 1216 },
    { 0x6c80, 1280 },
    { 0x6d00, 1344 },
    { 0x6d80, 1408 },
    { 0x4c00, 1472 },
    { 0x4c80, 1536 },
    { 0x4d00, 1600 },
    { 0x4d80, 1728 },
};

static ltable mwtable[] = {
	{ 0xf800, 5,  2, wm1 },
	{ 0xfc00, 6,  2, wm2 },
	{ 0xfe00, 7,  1, wm3 },
	{ 0xff00, 8,  6, wm4 },
	{ 0xff80, 9, 16, wm5 },
};
#define MWTANZ 5

/* black terminating tables */

static struct tableentry bt1[] = { /* 2 bits, left aligned */
    { 0xc000, 2 },
    { 0x8000, 3 },
};

static struct tableentry bt2[] = { /* 3 bits, left aligned */
    { 0x4000, 1 },
    { 0x6000, 4 },
};

static struct tableentry bt3[] = { /* 4 bits, left aligned */
    { 0x3000, 5 },
    { 0x2000, 6 },
};

static struct tableentry bt4[] = { /* 5 bits, left aligned */
    { 0x1800, 7 },
};

static struct tableentry bt5[] = { /* 6 bits, left aligned */
    { 0x1400, 8 },
    { 0x1000, 9 },
};

static struct tableentry bt6[] = { /* 7 bits, left aligned */
    { 0x0800, 10 },
    { 0x0a00, 11 },
    { 0x0e00, 12 },
};

static struct tableentry bt7[] = { /* 8 bits, left aligned */
    { 0x0400, 13 },
    { 0x0700, 14 },
};

static struct tableentry bt8[] = { /* 9 bits, left aligned */
    { 0x0c00, 15 },
};

static struct tableentry bt9[] = { /* 10 bits, left aligned */
    { 0x05c0, 16 },
    { 0x0600, 17 },
    { 0x0dc0, 0 },
    { 0x0200, 18 },
};

static struct tableentry bta[] = { /* 11 bits, left aligned */
    { 0x0ce0, 19 },
    { 0x0d00, 20 },
    { 0x0d80, 21 },
    { 0x06e0, 22 },
    { 0x0500, 23 },
    { 0x02e0, 24 },
    { 0x0300, 25 },
};

static struct tableentry btb[] = { /* 12 bits, left aligned */
    { 0x0ca0, 26 },
    { 0x0cb0, 27 },
    { 0x0cc0, 28 },
    { 0x0cd0, 29 },
    { 0x0680, 30 },
    { 0x0690, 31 },
    { 0x06a0, 32 },
    { 0x06b0, 33 },
    { 0x0d20, 34 },
    { 0x0d30, 35 },
    { 0x0d40, 36 },
    { 0x0d50, 37 },
    { 0x0d60, 38 },
    { 0x0d70, 39 },
    { 0x06c0, 40 },
    { 0x06d0, 41 },
    { 0x0da0, 42 },
    { 0x0db0, 43 },
    { 0x0540, 44 },
    { 0x0550, 45 },
    { 0x0560, 46 },
    { 0x0570, 47 },
    { 0x0640, 48 },
    { 0x0650, 49 },
    { 0x0520, 50 },
    { 0x0530, 51 },
    { 0x0240, 52 },
    { 0x0370, 53 },
    { 0x0380, 54 },
    { 0x0270, 55 },
    { 0x0280, 56 },
    { 0x0580, 57 },
    { 0x0590, 58 },
    { 0x02b0, 59 },
    { 0x02c0, 60 },
    { 0x05a0, 61 },
    { 0x0660, 62 },
    { 0x0670, 63 },
};

static ltable tbtable[] = {
	{ 0xc000,  2,  2, bt1 },
	{ 0xe000,  3,  2, bt2 },
	{ 0xf000,  4,  2, bt3 },
	{ 0xf800,  5,  1, bt4 },
	{ 0xfc00,  6,  2, bt5 },
	{ 0xfe00,  7,  3, bt6 },
	{ 0xff00,  8,  2, bt7 },
	{ 0xff80,  9,  1, bt8 },
	{ 0xffc0, 10,  4, bt9 },
	{ 0xffe0, 11,  7, bta },
	{ 0xfff0, 12, 38, btb },
};
#define TBTANZ 11

/* black makeup tables */

static struct tableentry bm1[] = { /* 10 bits, left aligned */
    { 0x03c0, 64 },
};

static struct tableentry bm2[] = { /* 12 bits, left aligned */
    { 0x0c80, 128 },
    { 0x0c90, 192 },
    { 0x05b0, 256 },
    { 0x0330, 320 },
    { 0x0340, 384 },
    { 0x0350, 448 },
};

static struct tableentry bm3[] = { /* 13 bits, left aligned */
    { 0x0360, 512 },
    { 0x0368, 576 },
    { 0x0250, 640 },
    { 0x0258, 704 },
    { 0x0260, 768 },
    { 0x0268, 832 },
    { 0x0390, 896 },
    { 0x0398, 960 },
    { 0x03a0, 1024 },
    { 0x03a8, 1088 },
    { 0x03b0, 1152 },
    { 0x03b8, 1216 },
    { 0x0290, 1280 },
    { 0x0298, 1344 },
    { 0x02a0, 1408 },
    { 0x02a8, 1472 },
    { 0x02d0, 1536 },
    { 0x02d8, 1600 },
    { 0x0320, 1664 },
    { 0x0328, 1728 },
};

static ltable mbtable[] = {
	{ 0xffc0, 10,  1, bm1 },
	{ 0xfff0, 12,  6, bm2 },
	{ 0xfff8, 13, 20, bm3 },
};
#define MBTANZ 3

#if 0
static struct tableentry extable[] = {
    { EXTABLE, 0x8, 11, 1792 },
    { EXTABLE, 0xc, 11, 1856 },
    { EXTABLE, 0xd, 11, 1920 },
    { EXTABLE, 0x12, 12, 1984 },
    { EXTABLE, 0x13, 12, 2048 },
    { EXTABLE, 0x14, 12, 2112 },
    { EXTABLE, 0x15, 12, 2176 },
    { EXTABLE, 0x16, 12, 2240 },
    { EXTABLE, 0x17, 12, 2304 },
    { EXTABLE, 0x1c, 12, 2368 },
    { EXTABLE, 0x1d, 12, 2432 },
    { EXTABLE, 0x1e, 12, 2496 },
    { EXTABLE, 0x1f, 12, 2560 },
    };
#endif
#endif /*_G3_H_*/
