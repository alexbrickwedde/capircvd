/* $Id: sff2misc.c,v 1.2 1998/10/08 13:28:34 fritz Exp $
 *
 * sff2pbm - a converter from StructuredFaxFormat to PortableBitMap
 *
 * (c) 1998 by Fritz Elfert
 *
 * $Log: sff2misc.c,v $
 * Revision 1.2  1998/10/08 13:28:34  fritz
 * Commandline-Switches ergaenzt.
 *
 * Revision 1.1  1998/10/08 10:41:34  fritz
 * Umbenannt nach sff2misc
 *
 * Revision 1.2  1998/10/08 09:06:20  fritz
 * Added jpeg and PostScript output.
 *
 * Revision 1.1  1998/10/07 04:27:49  fritz
 * First check in.
 *
 */
#include <stdio.h>

#include "sff.h"

void usage(void) {
	fprintf(stderr, "usage: sff2g3 -fmt SFFfile OutputfileBasename\n");
	fprintf(stderr, "       where fmt is:\n");
	fprintf(stderr, "         p  to produce PostScript\n");
	fprintf(stderr, "         j  to produce JPEG\n");
	fprintf(stderr, "         m  to produce PBM\n");
	exit(1);
}

void main(int argc, char **argv) {
	sff_file *f;
	int fmt;

	if (argc != 4)
		usage();
	if (argv[1][0] != '-')
		usage();
	switch (argv[1][1]) {
		case 'p':
			fmt = 2;
			break;
		case 'j':
			fmt = 1;
			break;
		case 'm':
			fmt = 0;
			break;
		default:
			usage();
	}
	f = open_sff(argv[2], "r");
	if (!f) {
		fprintf(stderr, "Could not open %s\n", argv[1]);
		exit(1);
	}
	decodeSFF(f, argv[3], fmt);
}
